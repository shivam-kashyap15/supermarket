# supermarket
A code snapshot for checkout in a supermarket, that allows multiple special prices for a product.
